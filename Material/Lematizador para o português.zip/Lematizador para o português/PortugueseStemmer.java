/*
 *    PortugueseStemmer.java
 *    Copyright (C) 2004-2005 Maria Abadia Lacerda Dias
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

package Interface;

import java.io.*;

/**
 * Implements a Portuguese stemmer. The algorithm is based on the paper
 * "A Stemming Algorithm for the Portuguese Language" by Vivianne Orengo
 * and Chris Huyck, in Proceedings of the SPIRE, November, 2001. Several
 * rules where updated and many exceptions and special cases where added.
 *
 * @author  Maria Abadia Lacerda Dias (mald@univates.br)
 * @version 1.0
 */
public class PortugueseStemmer /*extends Stemmer*/ implements Serializable {

  // TODO
  // - SRules d�o radical diretamente?
  // - modificar tamanho m�nimo de stem para tamanho da palavra?
  // - use a a HashMap instead of a String array?

  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

private static Rule[] plural = {
    // -NS
    new PRule("ns",      1, "m",  new String[] {"�ons", "el�trons", "pr�tons", "n�utrons", "f�tons", "epsilons"}), // EX: uns
    // -�ES, -�ES
    new PRule("�es",     1, "�o", new String[] {"m�es"}), // EX: p�es
    new PRule("�es",     2, "�o"), // EX: a��es
    // -IS
    new PRule("ais",     1, "al", new String[] {"cais", "mais", "pais", "demais", "ademais", "jamais", "anais"}), // EX: sais
    new PRule("�is",     1, "el", new String[] {"r�is"}), // EX: an�is
    new PRule("eis",     3, "el", new String[] {"f�sseis", "t�teis", "r�pteis", "f�ceis", "fr�geis", "t�xteis", "f�rteis", "inf�rteis", "vol�teis", "in�teis", "d�ceis", "ind�ceis", "est�reis", "h�beis", "in�beis", "port�teis", "d�beis", "m�sseis", "f�teis", "vibr�teis", "veroc�meis", "proj�teis"}), // EX: m�veis
    new PRule("eis",     2, "il"), // EX: �teis
    new PRule("�is",     3, "ol", new String[] {"her�is"}), // EX: anz�is
    new PRule("uis",     2, "ul", new String[] {"caquis", "sanguis", "croquis", "sambaquis"}), // EX: azuis
    new SRule("�lcoois",    "�lcool"),
    new PRule("is",      2, "il", new String[] {"l�pis", "cais", "mais", "cr�cis", "biqu�nis", "pois", "depois", "dois", "o�sis", "pais", "demais", "ademais", "jamais", "anais", "reis", "leis", "pr�xis", "quis", "t�nis", "s�filis", "p�nis", "bois", "gr�tis", "o�sis", "br�colis", "p�lvis", "j�ris", "�lcalis", "zumbis", "p�bis", "clit�ris", "b�lis", "bisturis", "�ris", "t�xis", "al�bis", "guris", "chassis", "abacaxis", "caquis", "sanguis", "croquis", "sambaquis"}), // EX: anis
    // -ES
    new PRule("les",     2, "l",  new String[] {"simples", "deles", "aqueles", "daqueles", "controles", "�queles", "neles", "naqueles", "vales", "peles", "is�sceles", "m�biles", "hip�rboles", "s�stoles", "metr�poles"}),// EX: males
    new PRule("nes",     4, "n",  new String[] {"perenes", "aut�ctones", "microfones", "cabines", "abor�genes", "telefones", "gramofones"}),// EX: c�nones
    new PRule("eses",    4, "�s", new String[] {"*teses", "*g�neses", "dioceses"}),// EX: chineses
    new PRule("ses",     1, "s",  new String[] {"*pses", "*sses", "*fases", "*frases", "*tases", "*oses", "*teses", "*enses", "*g�neses", "dioceses", "an�lises", "bases", "crises"}),// EX: ases
    new PRule("res",     1, "r",  new String[] {"*bres", "*cres", "*dres", "*fres", "*gres", "*tres", "*vres", "�rvores", "softwares", "hardwares", "pires", "escores", "torres", "hectares", "alferes", "alhures", "v�veres", "t�teres", "alqueires", "porres"}), // EX: ares
    new PRule("zes",     2, "z",  new String[] {"fezes", "deslizes", "varizes", "bronzes"}),// EX: vezes
    // -S
    new PRule("s",       1, "",   new String[] {"ali�s", "pires", "l�pis", "cais", "mais", "mas", "menos", "f�rias", "fezes", "p�sames", "cr�cis", "g�s", "atr�s", "tr�s", "detr�s", "mois�s", "atrav�s", "conv�s", "inv�s", "*�s", "pa�s", "ap�s", "ambas", "ambos", "messias", "o�sis", "�nibus", "dois", "duas", "tr�s", "depois", "rev�s", "seis", "dezesseis", "atlas", "alv�ssaras", "anais", "antolhos", "calendas", "c�s", "condol�ncias", "ex�quias", "fastos", "n�pcias", "m�s", "olheiras", "prim�cias", "v�veres", "vi�s", "demais", "ademais", "jamais", "r�is", "gr�tis", "br�colis", "p�lvis", "p�bis", "clit�ris", "�nus", "b�lis", "�ris", "is�sceles", "simples", "par�nteses", "apenas", "v�s", "n�s", "antes", "p�s", "deus", "c�s", "status", "caos", "�nus", "v�rus", "t�nus", "b�nus", "versus", "campus", "stress", "corpus", "trav�s"}), // EX: os
  };

  private static Rule[] adverb = {
    // -MENTE
    new PRule("mente", 4, "", new String[] {"movimente", "*argumente", "fragmente", "implemente", "incremente", "decremente", "experimente", "complemente", "*regulamente", "instrumente", "cumprimente", "arregimente", "fundamente", "suplemente", "sedimente", "parlamente", "documente", "*compartimente", "atormente", "*alimente", "ornamente", "regimente", "pavimente", "sacramente"}) // EX: premente
  };

  private static Rule[] feminine = {
    // -ORA
    new PRule("dora",      3, "dor"), // EX: amadora
    new PRule("sora",      3, "sor"), // EX: censora
    new PRule("tora",      2, "tor",   new String[] {"fatora"}), // EX: autora
    new SRule("senhora",      "senhor"),
  //new PRule("ana",       3, "ano",   new String[] {"semana", "banana", "membrana", "campana", "guiana", "porcelana", "caravana", "gincana", "bacana", "cabana", "nirvana", "roldana", "savana", "persiana", "ratazana"}), // EX: humana
  //new PRule("ena",       2, "eno",   new String[] {"*�gena", "arena", "antena", "quarentena", "dezena", "centena", "quinzena", "trena", "safena", "novena", "galena", "gangrena", "cadena", "cantilena", "hiena", "a�ucena",}), // EX:plena
  //new PRule("ina",       2, "ino",   new String[] {"*rotina", "*medicina", "*ficina", "m�quina", "resina", "p�gina", "dentina", "l�mina", "china", "marina", "retina", "bobina", "gasolina", "vitamina", "insulina", "piscina", "vagina", "esquina", "turbina", "cartolina", "cortina", "vacina", "parafina", "gelatina", "campina", "cantina", "margarina", "neblina", "faxina", "colina", "batina", "ravina", "rapina", "lamparina", "surdina", "propina", "toxina", "marina", "latrina", "jogatina", "tangerina", "botina", "maestrina"}), // EX: latina
    // -ONA
    new PRule("ona",       3, "�o",    new String[] {"*crona", "*erona", "*iona", "*lona", "*nona", "desabona", "abandona", "telefona", "sanfona", "ant�gona", "mamona", "japona", "corona", "poltrona", "matrona", "manjerona", "dipirona", "destrona", "persona", "un�sona", "*cortisona", "*metasona", "mon�tona", "maratona", "*cetona", "detona", "*ox�tona", "apaixona", "azeitona", "*zona"}), // EX: bobona
  //new PRule("rna",       2, "rno",   new String[] {"perna", "caverna", "lanterna", "caserna", "sarna", "baderna", "bigorna", "taberna", "cisterna", "taberna", "furna"}),  // EX: terna
  //new PRule("gna",       2, "gno"), // EX: digna
    // -ESA
    new SRule("baronesa",    "bar�o"),
    new SRule("duquesa",     "duque"),
    new SRule("princesa",    "pr�ncipe"),
    new PRule("esa",      4, "�s",    new String[] {"*presa", "*defesa", "despesa", "sobremesa", "turquesa"}), // EX: chinesa
  //new PRule("osa",      2, "oso",   new String[] {"mucosa", "prosa", "glosa"}), //EX: idosa
  //new PRule("usa",      2, "uso",   new String[] {"lousa", "cousa", "blusa", "deusa", "medusa", "hipotenusa", "menopausa"}),       // EX: difusa
  //new PRule("nsa",      2, "nso",   new String[] {"imprensa", "ofensa", "despensa"}), //EX: densa
  //new PRule("rsa",      2, "rso",   new String[] {"conversa", "farsa", "persa", "morsa"}), //EX: versa
  //new PRule("ossa",     1, "osso",  new String[] {"bossa", "crossa"}), //EX: nossa
  //new PRule("�aca",     3, "�aco"), //EX: man�aca
  //new PRule("ica",      2, "ico",   new String[] {"*r�plica", "rep�blica", "f�brica", "c�lica", "s�plica", "enc�clica", "rubrica"}), // EX: �nica
  //new PRule("ida",      1, "ido",   new String[] {"*icida", "*amida", "vida", "d�vida", "d�vida", "sobrevida", "avenida", "margarida", "gr�vida", "car�tida", "jazida", "revida", "guarida", }), // EX: lida
  //new PRule("�da",      2, "�do"), // EX: sa�da
  //new PRule("oda",      1, "odo" ,  new String[] {"soda", "ab�boda"}), // EX: toda
  //new PRule("uda",      1, "udo" ,  new String[] {"arruda", "cauda", "bermuda"}), // EX: muda
  //new PRule("lda",      2, "ldo" ,  new String[] {"esmeralda", "grinalda", "fralda"}), // EX: molda
  //new PRule("nda",      1, "ndo",   new String[] {"ainda", "onda", "fenda", "bunda", "umbanda", "microonda", "reprimenda", "berlinda", "microfenda", "abunda", "panda", "guirlanda", "barafunda", "microsonda"}), // EX: banda
  //new PRule("rda",      2, "rdo",   new String[] {"perda", "corda", "vanguarda", "retaguarda", "salvaguarda", "espingarda", "merda", "mostarda", "jarda"}), // EX: guarda
    // -�
    new PRule("�",        2, "�o",    new String[] {"manh�", "amanh�", "ma��", "xam�", "af�", "cl�", "*�m�", "div�", "suti�", "tit�", "tucum�", "marzip�"}), // EX: gr�
    // -�SIMA
    new PRule("�sima",    2, "�simo"), // EX: en�sima
    // -�SSIMA, -�RRIMA, -IVA, -EIRA
    new PRule("�ssima",   3, "�ssimo"), // EX: bel�ssima
    new PRule("�rrima",   3, "�rrimo"), // EX: alt�rrima
    new PRule("iva",      4, "ivo",   new String[] {"gengiva"}), // EX: efetiva
    new PRule("eira",     3, "eiro",  new String[] {"madeira", "cadeira", "ribeira", "bandeira", "esteira", "peneira", "ladeira", "derradeira", "requeira", "caveira", "lareira"}), // EX: ligeira
    // -IZADA, -ADA, -ENTA
    new PRule("izada",    4, "izado"), // EX: realizada
    new PRule("ada",      1, "ado",   new String[] {"*camada", "pitada", "entrada", "d�cada", "cada", "nada", "jornada", "palmada", "batelada", "enxada", "congada", "espada", "risada", "saraivada", "tonelada", "marmelada", "goiabada", "lombada", "camarada", "trovoada", "chuvarada", "toada", "ossada", "macacada", "granada", "g�nada", "alvorada", "chibatada", "salada", "peixada", "l�mpada", "meninada", "molecada", "mulherada", "crian�ada", "olimp�ada", "colherada", "facada", "panelada", "cilindrada", "escada", "cabe�ada", "cachorrada", "joelhada", "bofetada", "barrigada", "narigada", "manada", "lambada", "jangada", "porrada", "dentada", "cilada", "arcada", "mo�ada", "polegada", "garotada", "papelada", "pomada", "piazada", "balada", "almofada", "rapaziada", "feijoada", "ninhada", "bolada", "boiada"}), // EX: dada
    new PRule("enta",     3, "ento",  new String[] {"quarenta", "cinq�enta", "sessenta", "setenta", "oitenta", "noventa", "pimenta", "placenta", "tormenta", "parenta", "polenta", "magenta"}), // EX: aumenta
    // -OA
    new NRule("oa",          "�o",    new String[] {"leitoa", "patroa", "leoa"}),
    // -ISA
    new NRule("tisa",        "ta",    new String[] {"poetisa", "profetisa"}),
    new SRule("sacerdotisa", "sacerdote"),
    // -TRIZ
    new NRule("triz",        "tor",   new String[] {"atriz", "imperatriz"}),
    // ...
    new SRule("s�lfide",     "silfo"),
    new SRule("diaconisa",   "di�cono"),
    new SRule("�gua",        "cavalo"),
    new SRule("galinha",     "galo"),
    new SRule("maestrina",   "maestro"),
    new SRule("monja",       "monge"),
    new SRule("rainha",      "rei"),
  };

  private static Rule[] augmentative = {
    // -ZONA
    new PRule("zona",           3, "",   new String[] {"macrozona", "microzona", "subzona", "biozona", "*butazona"}), // EX: m�ezona
    // -�SSIMO
    new PRule("bil�ssimo",      3, "vel"), // EX: amabil�ssimo
    new SRule("antiqu�ssimo",      "antigo"),
    new PRule("qu�ssimo",       2, "co"), // EX: pouqu�ssimo
    new PRule("d�ssimo",        3, "do", new String[] {"grand�ssimo"}), // EX: lind�ssimo
    new SRule("amic�ssimo",        "amigo"),
    new SRule("dulc�ssimo",        "doce"),
    new PRule("c�ssimo",        4, "z"), // EX: feroc�ssimo
    new SRule("grandess�ssimo",    "grande"),
    new SRule("longu�ssimo",       "longo"),
    new PRule("�ssimo",         3), // EX: bel�ssimo
    // -�RRIMO
    new SRule("mag�rrimo",         "magro"),
    new SRule("paup�rrimo",        "pobre"),
    new PRule("�rrimo",         3), // EX: alt�rrimo
    // ...
    new PRule("alh�o",          3, "",   new String[] {"batalh�o", "trabalh�o", "trapalh�o", "medalh�o"}), // EX: vagalh�o
    new PRule("a�a",            3, "",   new String[] {"amea�a", "abra�a", "*fa�a", "caba�a", "*la�a", "espa�a", "emba�a", "desgra�a", "carca�a", "cacha�a", "carapa�a", "recha�a", "trapa�a", "*embara�a", "despeda�a", "estilha�a", "arrua�a", "*morda�a", "linha�a", "esvoa�a", "congra�a", "arrega�a"}), // EX: rica�a
    new PRule("a�o",            3, "",   new String[] {"*espa�o", "peda�o", "abra�o", "alma�o", "*bra�o", "palha�o", "*embara�o", "canga�o", "recha�o", "retra�o", "*fa�o", "morma�o"}), // EX: gola�o
    new PRule("u�a",            4), // EX: dentu�a
    new PRule("�zio",           3, "",   new String[] {"top�zio"}), // EX: cop�zio
    new PRule("arraz",          4), // EX: pratarraz
    new PRule("arra",           3, "",   new String[] {"esbarra", "cigarra", "bizarra", "fanfarra", "guitarra"}), // EX: bocarra
    new PRule("orra",           3), // EX: patorra
    new PRule("anzil",          4), // EX: corpanzil
    new PRule("ar�u",           3), // EX: fogar�u
    new PRule("astro",          4), // EX: poetastro
    new PRule("asta",           4, "",   new String[] {"contrasta", "desgasta", "desbasta"}), // EX: cineasta
    new PRule("asto",           4, "",   new String[] {"*plasto", "*blasto"}), // EX: padrasto
  //new PRule("ad�o",           3, "ad"), // EX: calad�o APENAS RETIRA �O
  //new PRule("ed�o",           1, "ed"), // EX: ded�o APENAS RETIRA �O
    // -�O
    new PRule("zarr�o",         3),  // EX: homenzarr�o
    new PRule("rr�o",           4, "",   new String[] {"empurr�o", "macarr�o", "chimarr�o"}),  // EX: beberr�o
    new PRule("z�o",            2, "",   new String[] {"*raz�o", "vaz�o", "priz�o", "coaliz�o"}),  // EX: pez�o
    new SRule("casar�o",           "casa"),
    new SRule("asneir�o",          "asno"),
    new SRule("toleir�o",          "tolo"),
    new SRule("vozeir�o",          "voz"),
    new SRule("narig�o",           "nariz"),
    new PRule("�o",             3, "", new String[] {"camar�o", "chimarr�o", "can��o", "cora��o", "embri�o", "grot�o", "glut�o", "fic��o", "fog�o", "fei��o", "furac�o", "gam�o", "lampi�o", "*le�o", "macac�o", "na��o", "�rf�o", "org�o", "patr�o", "port�o", "quinh�o", "rinc�o", "tra��o", "falc�o", "espi�o", "mam�o", "foli�o", "cord�o", "aptid�o", "campe�o", "colch�o", "lim�o", "leil�o", "mel�o", "bar�o", "milh�o", "bilh�o", "fus�o", "crist�o", "ilus�o", "esta��o", "sen�o"}), //perd�o, feij�o, macarr�o?
    // ...
    new SRule("fornalha",          "forno"),
    new SRule("gentalha",          "gente"),
    new SRule("muralha",           "muro"),
    new SRule("queixada",          "queixo"),
  };

  private static Rule[] diminutive = {
    // -INHA, -INHO
    new PRule("quinha",     2, "ca", new String[] {"mesquinha"}), // EX: vaquinha
    new PRule("quinho",     2, "co", new String[] {"mesquinho", "parquinho", "molequinho", "bosquinho", "chequinho"}), // EX: saquinho
    new PRule("guinha",     2, "ga", new String[] {"linguinha"}), // EX: ruguinha
    new PRule("guinho",     2, "go", new String[] {"sanguinho"}), // EX: joguinho
    new PRule("zinha",      2, "",   new String[] {"*vizinha", "cozinha", "vozinha", "luzinha", "belezinha", "brazinha"}), // EX: pazinha
    new PRule("zinho",      2, "",   new String[] {"*vizinho", "cozinho", "rapazinho", "quinzinho", "comezinho", "gizinho"}), // EX: pozinho
    new PRule("cinha",      2, "�a", new String[] {"docinha"}), // EX: mocinha
    new PRule("cinho",      2, "�o", new String[] {"focinho", "toicinho", "toucinho", "docinho", "ancinho"}), // EX: lacinho
    new SRule("asinha",        "asa"),
    new SRule("feinha",        "feia"),
    new SRule("joinha",        "j�ia"),
    new SRule("meinha",        "meia"),
    new SRule("sainha",        "saia"),
    new SRule("veinha",        "veia"),
    new PRule("inha",       3, "a",  new String[] {"*caminha", "mantinha", "continha", "farinha", "marinha", "espinha", "detinha", "*linha", "sobrinha", "obtinha", "convinha", "advinha", "campainha", "ladainha", "engatinha", "intervinha", "andorinha", "mesquinha", "*vizinha", "cozinha"}), // EX: bolinha
    new SRule("aninho",        "ano"),
    new SRule("radinho",       "radio"),
    new PRule("inho",       3, "o",  new String[] {"caminho", "carinho", "sobrinho", "marinho", "cadinho", "espinho", "redemoinho", "advinho", "engatinho", "pergaminho", "encaminho", "torvelinho", "cominho", "golfinho", "mesquinho", "*vizinho", "cozinho", "comezinho", "focinho", "toicinho", "toucinho", "ancinho"}), // EX: bobinho
    // -NINA, -NINO
    new SRule("pequenina",     "pequena"),
    new SRule("pequenino",     "pequeno"),
    // -IM
    new SRule("boletim",       "boleto"),
    new SRule("botequim",      "bar"),
    new SRule("camarim",       "camara"),
    new SRule("espadim",       "espada"),
    new SRule("festim",        "festa"),
    new SRule("folhetim",      "folha"),
    new SRule("fortim",        "forte"),
    // -ELHA, -ELHO
    new SRule("fedelha",       "feder"),
    new SRule("fedelho",       "feder"),
    new SRule("grupelho",      "grupo"),
    new SRule("rapazelho",     "rapaz"),
    // -EJO
    new SRule("animalejo",     "animal"),
    new SRule("festejo",       "festa"),
    new SRule("gracejo",       "gra�a"),
    new SRule("lugarejo",      "lugar"),
    new SRule("quitalejo",     "quintal"),
    new SRule("sertaneja",     "sert�o"),
    new SRule("sertanejo",     "sert�o"),
    new SRule("vilarejo",      "vila"),
    // -ILHA, -ILHO
    new SRule("vasilha",       "vaso"),
    new PRule("ilha",       4, "",   new String[] {"compartilha", "maravilha", "desempilha", "desvencilha", "fervilha", "engatilha", "lentilha"}), // EX: planilha
    new PRule("ilho",       4, "",   new String[] {"compartilho", "maravilho", "desempilho", "desvencilho", "fervilho", "engatilho"}), // EX: polvilho
    // -ACHO
    new SRule("fogacho",       "fogo"),
    new SRule("penacho",       "pena"),
    new SRule("popula�ho",     "povo"),
    new SRule("riacho",        "rio"),
    // -ICHA, -ICHO
    new SRule("barbicha",      "barba"),
    new SRule("governicho",    "governo"),
    // -UCHA, -UCHO
    new SRule("capucha",       "capa"),
    new SRule("casucha",       "casa"),
    new SRule("capucho",       "capa"),
    new SRule("cartucho",      "carta"),
    new SRule("gorducho",      "gordo"),
    new SRule("papelucho",     "papel"),
    new SRule("pequerrucho",   "pequeno"),
    // -EBRE
    new SRule("casebre",       "casa"),
    // -ECA, -ECO
    new SRule("boteco",        "bar"),
    new SRule("filmeco",       "filme"),
    new SRule("soneca",        "sono"),
    new SRule("folheca",       "folha"),
    new SRule("jornaleco",     "jornal"),
    new SRule("livreco",       "livro"),
    // -ICO
    new SRule("burrico",       "burro"),
    new SRule("amorico",       "amor"),
    new SRule("namorico",      "namoro"),
    // -ELA
    new SRule("ruela",         "rua"),
    new SRule("viela",         "via"),
    new SRule("cidadela",      "cidade"),
    new SRule("mordidela",     "morder"),
    new SRule("olhadela",      "olho"),
    new SRule("piscadela",     "piscar"),
    new SRule("sacudidela",    "sacudir"),
    // -ETE
    new PRule("onete",      3), // EX: sabonete
    new PRule("uete",       3), // EX: foguete
    new NRule("ete",           "",   new String[] {"balancete", "barrilete", "bracelete", "cacetete", "canivete", "capacete", "cartazete", "cavalete", "claquete", "clarinete", "corpete", "estilete", "florete", "lembrete", "martelete", "palacete", "patinete", "ramalhete", "rolete", "tablete", "trompete", "verbete", "artiguete", "malandrete"}),
    new SRule("disquete",      "disco"),
    new SRule("gabinete",      "cabine"),
    new SRule("charrete",      "carro"),
    // -ETA
    new PRule("oneta",      3), // EX: motoneta
    new NRule("queta",         "c",  new String[] {"barqueta", "fabriqueta", "plaqueta"}),
    new NRule("eta",           "",   new String[] {"bicicleta", "camiseta", "faceta", "motocicleta", "caderneta", "caixeta", "saleta", "carreta", "chupeta", "vareta", "prancheta", "mureta", "maleta", "corneta", "clarineta", "chaveta", "barqueta", "saleta", "papeleta", "maneta", "fabriqueta", "canaleta", "trombeta", "estatueta", "marreta", "historieta", "filipeta", "costeleta"}),
    new SRule("tabuleta",      "t�bua"),
    // -ETO
    new NRule("eto",           "",   new String[] {"livreto", "carreto", "poemeto", "verseto", "esboceto"}),
    new SRule("libreto",       "livro"),
    // -ZITA, -ZITO
    new SRule("florzita",      "flor"), // EX: florzita
    new SRule("jardinzito",    "jardim"), // EX: jardinzito
    // -ITA, -ITO
    new SRule("pequetita",     "pequena"),
    new NRule("ita",           "",   new String[] {"blusita", "camisita", "carmelita", "fulanita", "israelita", "salita", "saudita", "senhorita"}),
    new SRule("mosquito",      "mosca"),
    new SRule("palito",        "pau"),
    new SRule("pequetito",     "pequeno"),
    new NRule("ito",           "",   new String[] {"cabrito", "modelito", "negrito", "erudito", "rapazito"}),
    // -OTA, -OTE
    new SRule("velhota",       "velha"),
    new NRule("ote",           "",   new String[] {"filhote", "meninote", "grandote", "pequenote", "molecote", "fracote", "serrote", "velhote", "sacerdote", "cabe�ote", "caixote", "malote", "camarote"}),
    // -ISCA, -ISCO
    new NRule("isca",          "",   new String[] {"mourisca", "talisca"}),
    new NRule("isco",          "",   new String[] {"mourisco", "chuvisco", "levantisco", "pedrisco"}),
    // -USCA, -USCO
    new NRule("usca",          "",   new String[] {"velhusca"}),
    new NRule("usco",          "",   new String[] {"velhusco", "chamusco"}),
    // -OLA
    new NRule("ola",           "",   new String[] {"fazendola", "rapazola", "marola", "bandeirola", "camisola", "gabarola", "mariola", "casinhola", "ventarola", "pianola", "cachola"}),
    // -ULA, -ULO
    new NRule("�ncula",        "",   new String[] {"questi�ncula"}),
    new NRule("�nculo",        "",   new String[] {"hom�nculo", "ped�nculo"}),
    new NRule("�scula",        "",   new String[] {"mai�scula", "min�scula"}),
    new NRule("�sculo",        "",   new String[] {"corp�sculo", "op�sculo", "mai�sculo", "min�sculo"}),
    new NRule("�culo",         "",   new String[] {"vern�culo", "sustent�culo", "recept�culo", "habit�culo", "tabern�culo", "tent�culo"}),
    new NRule("�rculo",        "",   new String[] {"tub�rculo"}),
    new NRule("�cula",         "",   new String[] {"febr�cula", "got�cula", "part�cula", "pel�cula", "rad�cula", "matr�cula", "quadr�cula", "ves�cula"}),
    new NRule("�culo",         "",   new String[] {"mont�culo", "verm�culo", "vers�culo", "ventr�culo", "fol�culo", "fasc�culo", "test�culo", "cub�culo", "fun�culo", "ped�culo", "oss�culo", "mont�culo", "canal�culo"}),
    new NRule("ula",           "",   new String[] {"n�tula", "r�tula", "mol�cula"}),
    new NRule("ulo",           "",   new String[] {"gl�bulo", "gr�nulo",  "m�dulo", "n�dulo", "r�gulo"}),
  };

  private static Rule[] numeral = {
    new PRule("�simo", 2), // EX: en�simo
  };

  /*    new SRule("",    ""),
        new PRule("", ?, "", new String[] {"", ""}), // EX:
        new NRule("",    "", new String[] {"", ""}),
  */

  private static Rule[] noun = {
    // -ADO
    new PRule("bilizado",   2, "v"), // EX: mobilizado
    new PRule("alizado",    4), // EX: globalizado
    new PRule("atizado",    4), // EX: privatizado
    new PRule("tizado",     4), // EX: enfatizado
    new PRule("izado",      4), // EX: elitizado
    new PRule("ado",        2, "",   new String[] {"prado", "grado", "veado", "brado", "alado", "estado", "senado", "s�bado", "f�gado", "b�bado", "bocado", "rosado", "enfado", "c�vado", "mercado", "machado", "quadrado", "deputado", "telhado", "eldorado", "feriado"}),
    // -ENTO
    new PRule("guento",     4, "g"), // EX: briguento
    new PRule("quento",     4, "c"), // EX: melequento
    new NRule("ulento",        "",   new String[] {"corpulento", "turbulento", "fraudulento", "truculento", "purulento", "virulento"}),
    new SRule("sangrento",     "sangue"),
    new SRule("sonolento",     "sono"),
    new PRule("ento",       3, "",   new String[] {"*mento", "*vento", "*tento", "*sento", "enfrento", "talento", "acrescento", "sargento", "desalento", "relento", "rebento", "arrebento"}), // EX: nojento
    // -IVO
    new PRule("ativo",      4, ""), // EX: educativo
    new PRule("tivo",       4, ""), // EX: objetivo
    new SRule("defensivo",     "defender"),
    new PRule("ivo",        4, "",   new String[] {"arquivo", "passivo", "massivo", "ostensivo", "defensivo", "remissivo", "convivo", "cursivo", "compassivo", "lascivo", "elusivo"}), // EX: adesivo
    // -ISTA
    new PRule("encialista", 5), // EX: existencialista
    new PRule("alista",     5), // EX: capitalista
    new PRule("icionista",  4), // EX: nutricionista
    new PRule("cionista",   4), // EX: reducionista
    new PRule("ionista",    4), // EX: pensionista
    new NRule("tista",         "c",  new String[] {"cientista", "renascentista", "separatista", "corporatista", "preventista"}),
    new SRule("estatista",     "estado"),
    new PRule("ista",       3), // EX: artista
    // -AGEM
    new PRule("izagem",     6), // EX: aprendizagem
    new PRule("agem",       3, "",   new String[] {"mensagem", "*vantagem", "paisagem", "interagem", "homenagem", "bagagem", "*imagem", "massagem", "garagem", "chantagem", "estalagem", "fuselagem", "carenagem"}), // EX: passagem
    new NRule("agem",          "ag", new String[] {"mensagem", "*vantagem", "paisagem", "interagem", "homenagem", "bagagem", "*imagem", "massagem", "garagem", "chantagem", "estalagem", "fuselagem", "carenagem"}),
    // -MENTO
    new PRule("amento",     3, "",   new String[] {"filamento", "firmamento", "departamento"}), // EX: tratamento
    new PRule("imento",     3, "",   new String[] {"detrimento", "pavimento", "condimento"}), // EX: movimento
    // -IDO, -�DO
    new PRule("ido",        3, "",   new String[] {"l�quido", "marido", "fluido", "*v�lido", "s�lido", "h�brido", "r�gido", "*�xido", "libido", "n�tido", "t�mido", "bandido", "comprido", "valido", "*�cido", "p�lido", "liquido", "*l�cido", "l�mpido", "prurido", "m�rbido", "est�pido", "convido", "decido", "pl�cido", "espl�ndido", "s�rdido", "gr�vido", "ins�pido", "expl�ndido", "c�lido", "v�vido", "sustenido", "p�trido", "l�vido", "l�nguido", "f�lgido", "fl�cido", "anidrido", "t�rrido", "*�rido", "l�pido", "intr�pido", "imp�vido", "esqu�lido", "t�pido", "p�rfido", "fr�gido", "b�lido", "c�ndido", "duvido"}),
    new PRule("�do",        3, "",   new String[] {"*alde�do"}),

    /*---------------- n�o revisado ----------------*/
    // -OR
    new PRule("ador",       3), // EX: gerador
    new PRule("edor",       3), // EX: devedor
    new PRule("idor",       3), // EX: medidor
    new PRule("dor",        2, "d",  new String[] {"condor"}), // EX: pudor
    new PRule("ssor",       3, "ss"), //EX: emissor
    new PRule("sor",        4, "s"), //EX: divisor
    new PRule("tor",        3, "",   new String[] {"leitor", "doutor", "escritor", "monitor", "reitor", "pastor", "gestor", "agricultor", "benfeitor", "consultor"}), // EX: reator **parcialmente revisto**
    new PRule("or",         2, "",   new String[] {"maior", "menor", "melhor", "redor", "rigor", "tambor", "tumor", "pastor", "interior", "favor", "autor"}), // EX: valor
    // -ESCO
    new NRule("esco",          "",   new String[] {"burlesco", "principesco", "parentesco", "gigantesco", "romanesco"}),
    new PRule("esco",       4),

    new PRule("at�ria",     5),
    new PRule("oria",       4, "",   new String[] {"categoria"}),
    //new PRule(aria, gritaria, pirataria),
    //new PRule(ia, advocacia, reitoria),
    //new PRule(ia, alegria, valentia),

    new PRule("�rio",       3, "",   new String[] {"volunt�rio", "sal�rio", "anivers�rio", "*lion�rio", "arm�rio"}), // di�rio?
    new PRule("at�rio",     3),
    new PRule("rio",        5, "",   new String[] {"volunt�rio", "anivers�rio", "compuls�rio", "*lion�rio", "*st�rio"}), // di�rio, sal�rio, pr�prio, arm�rio?
    new PRule("�rio",       6),

    new PRule("abilidade",  5),
    new PRule("ividade",    5),
    new PRule("idade",      4, "",   new String[] {"autoridade", "comunidade"}),
    //new PRule(dade, dignidade, crueldade),

    new PRule("ionar",      5),

    new PRule("ional",      4),

    new PRule("�ncia",      3),
    new PRule("�ncia",      4, "",   new String[] {"ambul�ncia"}),

    new PRule("edouro",     3),

    new PRule("queiro",     3, "c"),
    new PRule("adeiro",     4, "",   new String[] {"desfiladeiro", "verdadeiro"}),
    new PRule("eiro",       3, "",   new String[] {"desfiladeiro", "pioneiro", "mosteiro"}),

    new PRule("uoso",       3),
    new PRule("oso",        3, "",   new String[] {"precioso"}),

    new PRule("aliza�",     5),
    new PRule("atiza�",     5),
    new PRule("tiza�",      5),
    new PRule("iza�",       5, "",   new String[] {"organiza�"}),
    new PRule("a�",         3, "",   new String[] {"equa�", "rela�"}), // -A��O
    new PRule("i�",         3, "",   new String[] {"elei�"}),

    new PRule("�s",         4),
    new PRule("eza",        3),
    new PRule("ez",         4),

    new PRule("ante",       2, "",   new String[] {"gigante", "elefante", "adiante", "possante", "instante", "restaurante"}),

    new PRule("�stico",     4, "",   new String[] {"eclesi�stico"}),
    new PRule("al�stico",   3),
    new PRule("�utico",     4),
    new PRule("�utico",     4),
    new PRule("�tico",      4, "",   new String[] {"alop�tico"}), // problem�tico, emblem�tico
    new PRule("tico",       3, "",   new String[] {"pol�tico", "eclesi�stico", "diagn�stico", "pr�tico", "dom�stico", "diagn�stico", "id�ntico", "alop�tico", "art�stico", "aut�ntico", "ecl�tico", "cr�tico", "critico"}),
    // �dico, dico
    new PRule("ico",        4, "",   new String[] {"*tico", "p�blico", "explico"}),

    new PRule("encial",     5),

    new PRule("auta",       5),

    new PRule("quice",      4, "c"),
    new PRule("ice",        4, "",   new String[] {"c�mplice"}),

    new PRule("�aco",       3),

    new PRule("ente",       4, "",   new String[] {"freq�ente", "alimente", "acrescente", "permanente", "aparente"}), // oriente?
    new PRule("ense",       5),

    new PRule("inal",       3),

    new PRule("ano",        4),

    new PRule("�vel",       2, "",   new String[] {"af�vel", "razo�vel", "pot�vel", "vulner�vel"}),
    new PRule("�vel",       3, "",   new String[] {"poss�vel"}),
    new PRule("vel",        5, "",   new String[] {"poss�vel", "vulner�vel"}), // sol�vel?

    new PRule("bil",        3, "vel"), // *vel?

    new PRule("ura",        4, "",   new String[] {"imatura", "acupuntura", "costura"}),

    new PRule("ural",       4),
    new PRule("ual",        3, "",   new String[] {"bissexual", "virtual", "visual", "pontual"}),
    new PRule("ial",        3),
    new PRule("al",         4, "",   new String[] {"afinal", "animal", "estatal", "bissexual", "desleal", "fiscal", "formal", "pessoal", "liberal", "postal", "virtual", "visual", "pontual", "sideral", "sucursal"}),

    new PRule("alismo",     4),
    new PRule("ivismo",     4),
    new PRule("ismo",       3, "",   new String[] {"cinismo"}),

    //Esses s�o sufixos que formam substantivos de outros substantivos...Ler 1�Observa��o, pg.96
    //new PRule(ato, carbonato, sulfato),
    //new PRule(alha, canalha, gentalha),
    //new PRule(ama, dinheirama),
    //new PRule(ame, vasilhame),
    //new PRule(edo, olivedo, vinhedo),
    //new PRule(eira, copeira, poeira),
    //new PRule(io, gentio, mulherio),
    //new PRule(ite, bronquite, gastrite),
    //new PRule(ugem, ferrugem, penugem),
    //new PRule(ume, cardume, negrume),

    //Esses s�o sufixos que formam substantivos de adjetivos...Ler 2� Observa��o, pg.96
    //new PRule(i(d�o), gratid�o, mansid�o),
    //new PRule(�cie, calv�cie, imund�cie),
    //new PRule(i(tude), altitude, magnitude),

    new PRule("quid",       3, "co"), // EX: rouquid�o
    new PRule("id",         3, "",   new String[] {"solid", "multid", "partid", "marid", "partid"}), // EX: aptid�o

    //Esses s�o sufixos que formam substantivos de verbos...Ler Observa��o, pg.98
    //new PRule(an�a, lembran�a, vingan�a),
    //new PRule(en�a, descren�a, diferen�a),
    //new PRule(inte, ouvinte, pedinte),
    //new PRule(��o, nomea��o, trai��o),
    //new PRule(s�o, agress�o, extens�o),
    //new PRule(douro, bebedouro, suadouro),
    //new PRule(t�rio, lavat�rio, vomit�rio),
    //new PRule(dura, atadura),
    //new PRule(tura, pintura, magistratura),
    //new PRule(sura, clausura, tonsura),

    //Esses s�o sufixos que formam adjetivos de substantivos...Ler Observa��o, pg.99

    //new PRule(aco, man�aco, austr�aco),
    //new PRule(aico, judaico, prosaico),
    //new PRule(ar, escolar, familiar),
    //new PRule(�o, alem�o, beir�o),
    //new PRule(engo, mulherengo),
    //new PRule(enho, ferrenho),
    //new PRule(eno, terreno),
    //new PRule(eo, r�seo, f�rreo),
    //new PRule(este, agreste, celeste),
    //new PRule(estre, campestre, terrestre),
    //new PRule(eu, europeu, hebreu),
    //new PRule(�cio, aliment�cio, natal�cio),
    //new PRule(il, febril, senhoril),
    //new PRule(ino, londrino, cristalino), � tamb�m diminutivo
    //new PRule(ita, israelita, islamita),
    //new PRule(onho, enfadonho),
    //new PRule(udo, pontudo, barbudo),

    //Esses s�o sufixos que formam adjetivos de verbos...Ler Observa��o, pg.100

    //new PRule(inte, constituinte, seguinte),
    //new PRule(io, tardio),
    //new PRule(d(i�o), movedi�o, quebradi�o),
    //new PRule(t(�cio), acomodat�cio, fact�cio),

    //Esses s�o sufixos verbais...pg.101

    //new PRule(ear, cabecear, folhear),
    //new PRule(ejar, gotejar, velejar),
    //new PRule(entar, amolentar),
    //new PRule(i(ficar), clarificar, dignificar),
    //new PRule(icar, bebericar, depenicar),
    //new PRule(ilhar, dedilhar, fervilhar),
    //new PRule(inhar, escrevinhar, cuspinhar),
    //new PRule(iscar, chuviscar, lambiscar),
    //new PRule(itar, dormitar, saltiar),
    //new PRule(izar, civilizar, utilizar),
  };

  private static PRule[] verb = {
    new PRule("ar�amo", 2),
    new PRule("�ssemo", 2),
    new PRule("er�amo", 2),
    new PRule("�ssemo", 2),
    new PRule("ir�amo", 3),
    new PRule("�ssemo", 3),
    new PRule("�ramo",  2),
    new PRule("�rei",   2),
    new PRule("aremo",  2),
    new PRule("ariam",  2),
    new PRule("ar�ei",  2),
    new PRule("�ssei",  2),
    new PRule("assem",  2),
    new PRule("�vamo",  2),
    new PRule("�ramo",  3),
    new PRule("eremo",  3),
    new PRule("eriam",  3),
    new PRule("er�ei",  3),
    new PRule("�ssei",  3),
    new PRule("essem",  3),
    new PRule("�ramo",  3),
    new PRule("iremo",  3),
    new PRule("iriam",  3),
    new PRule("ir�ei",  3),
    new PRule("�ssei",  3),
    new PRule("issem",  3),
    new PRule("ando",   2),
    new PRule("endo",   3),
    new PRule("indo",   3),
    new PRule("ondo",   3),
    new PRule("aram",   2),
    new PRule("ar�o",   2),
    new PRule("arde",   2),
    new PRule("arei",   2),
    new PRule("arem",   2),
    new PRule("aria",   2),
    new PRule("armo",   2),
    new PRule("asse",   2),
    new PRule("aste",   2),
    new PRule("avam",   2, "", new String[] {"agravam"}),
    new PRule("�vei",   2),
    new PRule("eram",   3),
    new PRule("er�o",   3),
    new PRule("erde",   3),
    new PRule("erei",   3),
    new PRule("�rei",   3),
    new PRule("erem",   3),
    new PRule("eria",   3),
    new PRule("ermo",   3),
    new PRule("esse",   3),
    new PRule("este",   3, "", new String[] {"faroeste", "agreste"}),// noroeste, sudeste, sudoeste ??
    new PRule("�amo",   3),
    new PRule("iram",   3),
    new PRule("�ram",   3),//ca�ram, sa�ram...Eu acho que tem que tirar o �ram e colocar o ir
    new PRule("ir�o",   2),
    new PRule("irde",   2),
    new PRule("irei",   3, "", new String[] {"admirei"}),//�rei(com acento agudo no i?
    new PRule("irem",   3, "", new String[] {"adquirem"}),
    new PRule("iria",   3),
    new PRule("irmo",   3),
    new PRule("isse",   3),
    new PRule("iste",   4),
    new PRule("iava",   4, "", new String[] {"ampliava"}), // ??
    new PRule("amo",    2),
    new PRule("iona",   3),// ??
    new PRule("ara",    2, "", new String[] {"arara", "prepara"}),
    new PRule("ar�",    2, "", new String[] {"alvar�"}),
    new PRule("are",    2, "", new String[] {"prepare"}),
    new PRule("ava",    2, "", new String[] {"agrava"}),
    new PRule("emo",    2),
    new PRule("era",    3, "", new String[] {"acelera", "espera"}),
    new PRule("er�",    3),
    new PRule("ere",    3, "", new String[] {"espere"}),// caberes do verbo caber
    new PRule("iam",    3, "", new String[] {"enfiam", "ampliam", "elogiam", "ensaiam"}),
    new PRule("�ei",    3),
    new PRule("imo",    3, "", new String[] {"reprimo", "intimo", "�ntimo", "*nimo", "queimo", "*ximo"}),
    new PRule("ira",    3, "", new String[] {"fronteira", "s�tira"}),
    new PRule("�do",    3),// ??
    new PRule("ir�",    3),
    new PRule("tizar",  4, "", new String[] {"alfabetizar"}),// ??
    new PRule("izar",   5, "", new String[] {"organizar"}),// ??
    new PRule("itar",   5, "", new String[] {"acreditar", "explicitar", "estreitar"}),// ??
    new PRule("ire",    3, "", new String[] {"adquire"}),
    new PRule("omo",    3),
    new PRule("ai",     2),
    new PRule("am",     2),
    new PRule("ear",    4, "", new String[] {"alardear", "nuclear"}),
    new PRule("ar",     2, "", new String[] {"azar", "bazar", "patamar"}),
    new PRule("uei",    3),
    new PRule("u�a",    5, "u"),
    new PRule("ei",     3),
    new PRule("guem",   3, "g"),
    new PRule("em",     2, "", new String[] {"*alem", "virgem"}),
    new PRule("er",     2, "", new String[] {"�ter", "pier"}),
    new PRule("eu",     3, "", new String[] {"chapeu"}), // chap�u?
    new PRule("ia",     3, "", new String[] {"est�ria", "fatia", "*acia", "praia", "elogia", "mania", "l�bia", "aprecia", "pol�cia", "arredia", "cheia", "*�sia"}),
    new PRule("ir",     3, "", new String[] {"freir"}),
    new PRule("iu",     3),
    new PRule("eou",    5),
    new PRule("ou",     3),
    new PRule("i",      3) //cai do verbo cair, tem que tirar o i e colocar o ir. Tem que colocar todas as termina��es das
    //conjuga��es do verbo cair

   //new PRule(ado, cantado),
   //new PRule(ido, vendido, partido),
  };

  private static PRule[] thematic_vowel = { //Tem que revisar!!!
    new PRule("bil", 2, "vel"), // ????
    new PRule("gue", 2, "g", new String[] {"gangue", "jegue"}),
    new PRule("�",   3),
    new PRule("�",   3, "",  new String[] {"beb�"}),
    new PRule("a",   3, "",  new String[] {"�sia"}),
    new PRule("e",   3),
    new PRule("o",   3, "",  new String[] {"*�o"})
    // new PRule("spa�o",         1, "spac"),  // O QUE FAZER COM O �EDILHA???
    // o que fazer com o �O?
    // o que fazer com o �Z?
  };

  /**
   * Apply the given rule set to word
   */
  private boolean applyRules(StringBuffer word, Rule[] rules)
  {
    boolean changed = false;
    for (int i = 0; i < rules.length; i++) {
      changed = rules[i].apply(word);
      if (changed) {
        // do not apply remaining rules
        break;
      }
    }
    return changed;
  }

  /**
   * Replace accented characters for normal ones
   */
  private void removeAccents(StringBuffer word)
  {
    for (int i = 0; i < word.length(); i++) {
      switch (word.charAt(i)) {
      case '�':
      case '�':
      case '�':
      case '�':
        word.setCharAt(i, 'a');
        break;
      case '�':
      case '�':
        word.setCharAt(i, 'e');
        break;
      case '�':
        word.setCharAt(i, 'i');
        break;
      case '�':
      case '�':
      case '�':
        word.setCharAt(i, 'o');
        break;
      case '�':
      case '�':
        word.setCharAt(i, 'u');
        break;
      }
    }
  }

  private boolean verbose = false;
  public void setVerbose()
  {
    verbose = true;
  }

  /**
   * Returns the stemmed version of the given word.
   *
   * @param word a string consisting of a single word
   */
  public String stem(String word) {
    StringBuffer w = new StringBuffer(word.toLowerCase());
    //boolean changed;
    int n = w.length();
    if (n > 2) {
      if (w.charAt(n - 1) == 's') {
        if (applyRules(w, plural)) {
          if (verbose) System.out.print("PLU ");
        }
      }
      if (applyRules(w, adverb)) {
        if (verbose) System.out.print("ADV ");
      }
      n = w.length();
      if (w.charAt(n - 1) == 'a') {
        if (applyRules(w, feminine)) {
          if (verbose) System.out.print("FEM ");
        }
      }
      if (applyRules(w, augmentative)) {
        if (verbose) System.out.print("AUM ");
      }
      else {
        if (applyRules(w, diminutive)) {
          if (verbose) System.out.print("DIM ");
        }
      }
      if (applyRules(w, numeral)) {
        if (verbose) System.out.print("NUM ");
      }
      if (applyRules(w, noun)) {
        if (verbose) System.out.print("NOM ");
      }
      else {
        if (applyRules(w, verb)) {
          if (verbose) System.out.print("VER ");
        }
        else {
          if (applyRules(w, thematic_vowel)) {
            if (verbose) System.out.print("VOG ");
          }
        }
      }
      removeAccents(w);
    }
    return w.toString();
  }

  /**
   * Validate given rules
   */
  private void validateRules(Rule[] rules)
  {
    for (int i = 0; i < rules.length; i++) {
      rules[i].validate();
    }
  }

  /**
   * Validate all rules
   */
  public void validate()
  {
    validateRules(plural);
    validateRules(adverb);
    validateRules(feminine);
    validateRules(augmentative);
    validateRules(diminutive);
    validateRules(numeral);
    validateRules(noun);
    validateRules(verb);
    validateRules(thematic_vowel);
  }

  /**
   * Stems text coming into stdin and writes it to stdout.
   *//*
  public static void main(String[] args) {

    PortugueseStemmer ms = new PortugueseStemmer();

    ms.validate();
    if (args.length != 0) {
      System.out.println("-- verbose mode --");
      ms.setVerbose();
    }

    try {
      int num;
      StringBuffer wordBuffer = new StringBuffer();
      while ((num = System.in.read()) != -1) {
        //System.out.printf("\n num: %d, %c : char \n",num,(char)num);
        char c = (char)num;
        if (Character.isLetter(c)) {
          wordBuffer.append(c);
        }
        else {
          if (wordBuffer.length() > 0) {
            System.out.print(ms.stem(wordBuffer.toString()));
            wordBuffer = new StringBuffer();
          }
          System.out.print(c);
        }
      }
    }
    catch (Exception e) {
      System.err.println(e.getMessage());
    }
  }*/
}

/**
 * Base abstract rule
 */
abstract class Rule {
  public abstract boolean apply(StringBuffer word);
  public abstract void validate();
}

/**
 * Negative rule: replace suffix for just the matches given
 */
class NRule extends Rule {
  private String suffix;
  private String replacement;
  private String[] matches;

  public NRule(String suffix, String replacement, String[] matches)
  {
    this.suffix = suffix;
    this.replacement = replacement;
    this.matches = matches;
  }

  public boolean apply(StringBuffer word)
  {
    int wlen = word.length();
    int slen = suffix.length();

    // check whether the word ends with the suffix
    if (word.indexOf(suffix, wlen - slen) == -1) {
      return false;
    }

    // it ends with the suffix, should ensure it is one of the matches
    if (matches != null) {
      for (int i = 0; i < matches.length; i++) {
        if (matches[i].contentEquals(word)) {
          // strip suffix and append replacement if present
          word.replace(wlen - slen, wlen, replacement);
          return true;
        }
      }
    }

    // no matches found
    return false;
  }

  public void validate()
  {
    if (suffix == null || suffix.length() == 0 || replacement == null) {
      System.out.println("invalid NRule '" + suffix + "' -> '" + replacement + "'");
    }
    if (matches == null || matches.length == 0) {
      System.out.println("invalid NRule '" + suffix + "': match list cannot be null or empty");
    }
    for (int i = 0; i < matches.length; i++) {
      if (! matches[i].endsWith(suffix)) {
        System.out.println("invalid NRule '" + suffix + "': match '" + matches[i] + "' does not end with suffix");
      }
    }
  }
}

/**
 * Positive rule: replace suffix for all matching words, however taking into account the exception list
 */
class PRule extends Rule {
  private String suffix;
  private int minimum_length;
  private String replacement;
  private String[] exceptions;

  public PRule()
  {
  }
  public PRule(String suffix, int minimum_length)
  {
    this.suffix = suffix;
    this.minimum_length = minimum_length;
    this.replacement = "";
  }
  public PRule(String suffix, int minimum_length, String replacement)
  {
    this.suffix = suffix;
    this.minimum_length = minimum_length;
    this.replacement = replacement;
  }
  public PRule(String suffix, int minimum_length, String replacement, String[] exceptions)
  {
    this.suffix = suffix;
    this.minimum_length = minimum_length;
    this.replacement = replacement;
    this.exceptions = exceptions;
  }

  public boolean apply(StringBuffer word)
  {
    int wlen = word.length();
    int slen = suffix.length();

    // check whether the minimum stem length is satisfied
    if (wlen - slen < minimum_length) {
      return false;
    }

    // check whether the word ends with the suffix
    if (word.indexOf(suffix, wlen - slen) == -1) {
      return false;
    }

    // it ends with the suffix, but first check whether it is one of the exceptions
    if (exceptions != null) {
      for (int i = 0; i < exceptions.length; i++) {
        if (exceptions[i].charAt(0) == '*') {
          // match exception suffix
          if (word.indexOf(exceptions[i].substring(1), wlen - exceptions[i].length() - 1) != -1) {
            return false;
          }
        }
        else {
          // match exception
          if (exceptions[i].contentEquals(word)) {
            return false;
          }
        }
      }
    }

    // strip suffix and append replacement if present
    word.replace(wlen - slen, wlen, replacement);
    return true;
  }

  public void validate()
  {
    int slen = suffix.length();
    if (suffix == null || slen == 0 || minimum_length < 1 || minimum_length > 6 || replacement == null) {
      System.out.println("invalid PRule '" + suffix + "', " + minimum_length + " -> '" + replacement + "'");
    }
    if (exceptions != null) {
      if (exceptions.length == 0) {
        System.out.println("invalid PRule '" + suffix + "': exception list exists but is empty");
      }
      for (int i = 0; i < exceptions.length; i++) {
        if (! exceptions[i].endsWith(suffix)) {
          System.out.println("invalid PRule '" + suffix + "': exception '" + exceptions[i] + "' does not end with suffix");
        }
        if (exceptions[i].charAt(0) != '*' && exceptions[i].length() < slen + minimum_length) {
          System.out.println("invalid PRule '" + suffix + "': exception '" + exceptions[i] + "' does not have minimum length");
        }
      }
    }
  }
}

/**
 * Simple substitution rule
 */
class SRule extends Rule {
  private String word;
  private String substitution;

  public SRule(String word, String substitution)
  {
    this.word = word;
    this.substitution = substitution;
  }

  public boolean apply(StringBuffer word)
  {
    if (this.word.contentEquals(word)) {
      word.replace(0, word.length(), substitution);
      return true;
    }
    return false;
  }

  public void validate()
  {
    if (word == null || substitution == null || word.length() == 0 || substitution.length() == 0) {
      System.out.println("invalid SRule '" + word + "' -> '" + substitution + "'");
    }
  }
}
